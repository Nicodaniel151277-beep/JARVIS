const express = require("express");
const path = require("path");
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const memories = [];
app.get("/api/status", (_req, res) => res.json({ online: true, name: "J.A.R.V.I.S." }));
app.get("/api/memories", (_req, res) => res.json({ memories }));
app.post("/api/memories", (req, res) => {
  const text = String(req.body?.text || "").trim();
  if (!text) return res.status(400).json({ error: "Bitte einen Inhalt eingeben." });
  memories.push({ text, createdAt: new Date().toISOString() });
  res.json({ ok: true, memories });
});
app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "Nachricht fehlt." });
  if (!process.env.OPENAI_API_KEY) {
    return res.json({ reply: "Ich bin online, aber mein KI-Schlüssel ist noch nicht eingerichtet. Bitte hinterlege OPENAI_API_KEY sicher in den Server-Umgebungsvariablen." });
  }
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          { role: "system", content: "Du bist J.A.R.V.I.S., ein hilfreicher deutschsprachiger persönlicher KI-Assistent. Antworte freundlich, klar und präzise. Behaupte nicht, iPhone-Funktionen ausführen zu können, wenn du das nicht kannst." },
          { role: "user", content: message }
        ]
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || "KI-Anfrage fehlgeschlagen.");
    res.json({ reply: data.choices?.[0]?.message?.content || "Ich konnte gerade keine Antwort erstellen." });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`J.A.R.V.I.S. läuft auf Port ${port}`));
