J.A.R.V.I.S. – iPhone Edition (Starterprojekt)

Dieses Projekt ist eine mobile Web-App mit Iron-Man-inspirierter Oberfläche.
Es ist noch nicht online und benötigt Hosting mit Node.js.

Einrichtung:
1. Dateien in ein GitHub-Repository hochladen.
2. Bei einem Node.js-Hoster das Repository verbinden.
3. Build-Befehl leer lassen; Start-Befehl: npm start
4. OPENAI_API_KEY als geheime Umgebungsvariable im Hosting-Dashboard setzen.
5. Die öffentliche HTTPS-Adresse auf dem iPhone in Safari öffnen.
6. Safari: Teilen > Zum Home-Bildschirm.

Wichtig:
- Niemals den API-Schlüssel in GitHub oder in öffentliche Dateien schreiben.
- KI-Anfragen können kostenpflichtig sein.
- Sprachsteuerung hängt von der Browser-Unterstützung ab.
- iOS-Web-Apps können nicht dauerhaft im Hintergrund auf ein Aktivierungswort lauschen
  und nicht beliebig iPhone-Systemfunktionen steuern.
- Die Beispiel-Merkliste liegt nur im Arbeitsspeicher und wird beim Serverneustart gelöscht.
